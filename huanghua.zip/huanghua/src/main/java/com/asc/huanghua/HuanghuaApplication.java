package com.asc.huanghua;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HuanghuaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HuanghuaApplication.class, args);
	}

}
